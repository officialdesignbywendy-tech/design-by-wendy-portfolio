# Images still to add

Your original images were not inside the first ZIP, so the images listed below are still pointers
to Lovable's image storage (`/__l5e/...`). They show on the Lovable preview but will appear
**broken on Vercel** until you add the real files.

**How to add them (about two minutes):**
1. Put all your original image files in one folder on your computer (sub-folders are fine).
   File names must match the "File name" column (capital letters and spaces don't matter).
2. In the project folder run:  `node scripts/localize-assets.mjs "path/to/your/images"`
   It copies each image into `public/images/` and updates the pointer files. No other code changes.
3. The script prints any files it could not find. Add those and run it again.
4. Commit and push. Vercel rebuilds.

Or send the images back to me and I will do this step for you.

| Group (inside src/assets) | File name |
|---|---|
| (top level) | wendy-about-artboard.jpg |
| (top level) | wendy-portrait-2.png |
| (top level) | wendy-portrait.png |
| case-studies | divaluxe-flyer.jpg |
| case-studies | divaluxe-mockup-frame.png |
| case-studies | divaluxe-mockup-hands.png |
| case-studies | divaluxe-mockup-studio.png |
| case-studies | glow-up-event-flyer.jpg |
| case-studies | glow-up-mockup-1.png |
| case-studies | glow-up-mockup-2.png |
| case-studies | glow-up-mockup-3.png |
| case-studies | glow-up-mockup-4.png |
| other-projects | burger-spot-opening.jpg |
| other-projects | crunchbite-grand-opening.jpg |
| other-projects | floral-threads-crochet-fashion.jpeg |
| other-projects | floral-threads-original.jpg |
| other-projects | haven-crest-cart-home.png |
| other-projects | haven-crest-egg-home.png |
| other-projects | haven-crest-ice-home.png |
| other-projects | haven-crest-main-property.png |
| other-projects | haven-crest-shadow-home.png |
| other-projects | haven-crest-suitcase-home.png |
| other-projects | nexora-bus-stop-mockup.png |
| other-projects | nexora-campaign-poster.png |
| other-projects | nexora-logo-black.png |
| other-projects | nexora-logo-white.png |
| other-projects | pen-and-purpose-hub.jpg |
| other-projects | purepress-juice.jpg |
| other-projects | savory-spoon-menu.jpg |
| other-projects | sweet-crumbs-bakery.jpg |
| other-projects | welcome-august.jpg |
| other-projects | wendy-resume.jpg |
| rhythm | detail-footer.jpg |
| rhythm | detail-header.jpg |
| rhythm | detail-prize.jpg |
| rhythm | detail-title.jpg |
| rhythm | flyer-full.jpg |
| rhythm | mockup-billboard.png |
| rhythm | mockup-instagram.png |
| rhythm | mockup-poster.png |
| rhythm | mockup-street.png |

Notes
- `wendy-portrait.png` must be the transparent (background-removed) cut-out. It is the hero portrait.
- Already included and working: everything in `public/hero/` and `public/about/` (the hero icons, star and About portrait).
- `src/assets/hero.jpg`, `project-1..6.jpg` and `wendy.jpg` are original local files kept for safety. The current site does not use them.
