// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { mcpPlugin } from "@lovable.dev/mcp-js/stacks/tanstack/vite";

// Vercel sets VERCEL=1 during its builds. The Lovable config defaults Nitro to a Cloudflare
// target, so on Vercel we select Nitro's "vercel" preset, which writes the Vercel
// Build Output API folder (.vercel/output). Everywhere else (Lovable preview, local dev)
// the original behaviour is unchanged.
const onVercel = Boolean(process.env.VERCEL);

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  ...(onVercel ? { nitro: { preset: "vercel" } } : {}),
  vite: {
    plugins: [mcpPlugin()],
  },
});
